import TicketChart from "../components/chart/TicketChart";

const Statistics: React.FC = () => {
  return (
    <>
      <TicketChart></TicketChart>
    </>
  );
};

export default Statistics;
