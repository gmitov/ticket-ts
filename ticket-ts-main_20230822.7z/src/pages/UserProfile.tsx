const UserProfile: React.FC = () => {
  return <div>User Profile</div>;
};

export default UserProfile;
