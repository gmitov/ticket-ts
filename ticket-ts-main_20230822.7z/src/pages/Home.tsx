const Home: React.FC = () => {
  return <div>Home</div>;
};

export default Home;
