const serverUrl = import.meta.env.VITE_SERVER_URL;

export default serverUrl;
