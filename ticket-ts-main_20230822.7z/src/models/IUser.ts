interface IUser {
  accToken: string;
  refreshToken: string;
  experesIn: string;
  nUser: number;
  userBULSTAT: string;
  userEmail: string;
  userFirstName: string;
  userSecondName: string;
  userLastName: string;
  userFirmName: string;
  userType: string;
  error: string;
}
